# HiddenAnaconda - system obsługi przewoźnika komunikacji miejskiej 
<p align="center">
  <img width="260" height="260" src="https://i.imgur.com/FEbFLTx.png">
</p>
<p>
Projekt jest tworzony w <b>.NETFramework</b> w wersji <b>4.6.1</b>
  Do generacji PDF'a używamy https://ironpdf.com
</p>
