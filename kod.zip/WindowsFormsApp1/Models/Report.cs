namespace hiddenAnaconda.Models {
    partial class ReportDataContext {
    }
}