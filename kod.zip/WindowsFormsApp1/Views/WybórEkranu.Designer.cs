﻿namespace hiddenAnaconda.Views {
    partial class WybórEkranu {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WybórEkranu));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Time = new System.Windows.Forms.Label();
            this.hello = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Wyloguj = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.uzytkownicyEdycja = new System.Windows.Forms.Button();
            this.uzytkownicy = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.czasyRealizacje = new System.Windows.Forms.Button();
            this.statusZmiana = new System.Windows.Forms.Button();
            this.kursyPrzypisanie = new System.Windows.Forms.Button();
            this.trasyZarzadzanie = new System.Windows.Forms.Button();
            this.kierowcy = new System.Windows.Forms.Button();
            this.Raport = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pojazdy = new System.Windows.Forms.Button();
            this.przystanki = new System.Windows.Forms.Button();
            this.linie = new System.Windows.Forms.Button();
            this.kursy = new System.Windows.Forms.Button();
            this.terminyKursowania = new System.Windows.Forms.Button();
            this.create = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.help = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.Wyloguj);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.create);
            this.panel1.Location = new System.Drawing.Point(2, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(606, 377);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.Time);
            this.panel5.Controls.Add(this.hello);
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Location = new System.Drawing.Point(-1, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(608, 56);
            this.panel5.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Wybierz formularz i zacznij pracę.";
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Time.Location = new System.Drawing.Point(461, 3);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(139, 15);
            this.Time.TabIndex = 29;
            this.Time.Text = "10.04.2013 22:50:44";
            // 
            // hello
            // 
            this.hello.AutoSize = true;
            this.hello.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hello.Location = new System.Drawing.Point(59, 10);
            this.hello.Name = "hello";
            this.hello.Size = new System.Drawing.Size(51, 16);
            this.hello.TabIndex = 28;
            this.hello.Text = "label1";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(54, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            // 
            // Wyloguj
            // 
            this.Wyloguj.Location = new System.Drawing.Point(102, 339);
            this.Wyloguj.Name = "Wyloguj";
            this.Wyloguj.Size = new System.Drawing.Size(80, 30);
            this.Wyloguj.TabIndex = 35;
            this.Wyloguj.Text = "Wyloguj";
            this.Wyloguj.UseVisualStyleBackColor = true;
            this.Wyloguj.Click += new System.EventHandler(this.Wyloguj_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Window;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.pictureBox5);
            this.panel4.Controls.Add(this.uzytkownicyEdycja);
            this.panel4.Controls.Add(this.uzytkownicy);
            this.panel4.Location = new System.Drawing.Point(398, 66);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(180, 263);
            this.panel4.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(60, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 43);
            this.label6.TabIndex = 6;
            this.label6.Text = "Zarządzanie\r\nużytkownikami";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::hiddenAnaconda.Properties.Resources._83402_200;
            this.pictureBox5.Location = new System.Drawing.Point(3, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(51, 43);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // uzytkownicyEdycja
            // 
            this.uzytkownicyEdycja.Location = new System.Drawing.Point(25, 95);
            this.uzytkownicyEdycja.Margin = new System.Windows.Forms.Padding(2);
            this.uzytkownicyEdycja.Name = "uzytkownicyEdycja";
            this.uzytkownicyEdycja.Size = new System.Drawing.Size(130, 30);
            this.uzytkownicyEdycja.TabIndex = 12;
            this.uzytkownicyEdycja.Text = "Edycja użytkowników";
            this.uzytkownicyEdycja.UseVisualStyleBackColor = true;
            this.uzytkownicyEdycja.Click += new System.EventHandler(this.button3_Click);
            // 
            // uzytkownicy
            // 
            this.uzytkownicy.Location = new System.Drawing.Point(25, 51);
            this.uzytkownicy.Margin = new System.Windows.Forms.Padding(2);
            this.uzytkownicy.Name = "uzytkownicy";
            this.uzytkownicy.Size = new System.Drawing.Size(130, 40);
            this.uzytkownicy.TabIndex = 11;
            this.uzytkownicy.Text = "Tworzenie użytkowników";
            this.uzytkownicy.UseVisualStyleBackColor = true;
            this.uzytkownicy.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.czasyRealizacje);
            this.panel3.Controls.Add(this.statusZmiana);
            this.panel3.Controls.Add(this.kursyPrzypisanie);
            this.panel3.Controls.Add(this.trasyZarzadzanie);
            this.panel3.Controls.Add(this.kierowcy);
            this.panel3.Controls.Add(this.Raport);
            this.panel3.Location = new System.Drawing.Point(211, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(181, 263);
            this.panel3.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(60, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 43);
            this.label5.TabIndex = 6;
            this.label5.Text = "Zarządzanie \r\ni raporty";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::hiddenAnaconda.Properties.Resources.img_381234;
            this.pictureBox4.Location = new System.Drawing.Point(3, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(51, 43);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // czasyRealizacje
            // 
            this.czasyRealizacje.Location = new System.Drawing.Point(25, 51);
            this.czasyRealizacje.Margin = new System.Windows.Forms.Padding(2);
            this.czasyRealizacje.Name = "czasyRealizacje";
            this.czasyRealizacje.Size = new System.Drawing.Size(130, 30);
            this.czasyRealizacje.TabIndex = 5;
            this.czasyRealizacje.Text = "Czasy realizacji kursu";
            this.czasyRealizacje.UseVisualStyleBackColor = true;
            this.czasyRealizacje.Click += new System.EventHandler(this.Czas_Click);
            // 
            // statusZmiana
            // 
            this.statusZmiana.Location = new System.Drawing.Point(25, 153);
            this.statusZmiana.Margin = new System.Windows.Forms.Padding(2);
            this.statusZmiana.Name = "statusZmiana";
            this.statusZmiana.Size = new System.Drawing.Size(130, 30);
            this.statusZmiana.TabIndex = 8;
            this.statusZmiana.Text = "Zmiana statusu";
            this.statusZmiana.UseVisualStyleBackColor = true;
            this.statusZmiana.Click += new System.EventHandler(this.ZmianaStatusu_Click);
            // 
            // kursyPrzypisanie
            // 
            this.kursyPrzypisanie.Location = new System.Drawing.Point(25, 85);
            this.kursyPrzypisanie.Margin = new System.Windows.Forms.Padding(2);
            this.kursyPrzypisanie.Name = "kursyPrzypisanie";
            this.kursyPrzypisanie.Size = new System.Drawing.Size(130, 30);
            this.kursyPrzypisanie.TabIndex = 6;
            this.kursyPrzypisanie.Text = "Przypisanie do kursu";
            this.kursyPrzypisanie.UseVisualStyleBackColor = true;
            this.kursyPrzypisanie.Click += new System.EventHandler(this.Przypisanie_Click);
            // 
            // trasyZarzadzanie
            // 
            this.trasyZarzadzanie.Location = new System.Drawing.Point(25, 223);
            this.trasyZarzadzanie.Margin = new System.Windows.Forms.Padding(2);
            this.trasyZarzadzanie.Name = "trasyZarzadzanie";
            this.trasyZarzadzanie.Size = new System.Drawing.Size(130, 30);
            this.trasyZarzadzanie.TabIndex = 10;
            this.trasyZarzadzanie.Text = "Zarządzanie trasami";
            this.trasyZarzadzanie.UseVisualStyleBackColor = true;
            this.trasyZarzadzanie.Click += new System.EventHandler(this.Trasa_Click);
            // 
            // kierowcy
            // 
            this.kierowcy.Location = new System.Drawing.Point(25, 119);
            this.kierowcy.Margin = new System.Windows.Forms.Padding(2);
            this.kierowcy.Name = "kierowcy";
            this.kierowcy.Size = new System.Drawing.Size(130, 30);
            this.kierowcy.TabIndex = 7;
            this.kierowcy.Text = "Dodawanie kierowców";
            this.kierowcy.UseVisualStyleBackColor = true;
            this.kierowcy.Click += new System.EventHandler(this.Kierowca_Click);
            // 
            // Raport
            // 
            this.Raport.Location = new System.Drawing.Point(25, 188);
            this.Raport.Name = "Raport";
            this.Raport.Size = new System.Drawing.Size(130, 30);
            this.Raport.TabIndex = 9;
            this.Raport.Text = "Tworzenie raportu";
            this.Raport.UseVisualStyleBackColor = true;
            this.Raport.Click += new System.EventHandler(this.RaportButton_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.pojazdy);
            this.panel2.Controls.Add(this.przystanki);
            this.panel2.Controls.Add(this.linie);
            this.panel2.Controls.Add(this.kursy);
            this.panel2.Controls.Add(this.terminyKursowania);
            this.panel2.Location = new System.Drawing.Point(25, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(180, 263);
            this.panel2.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(58, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 43);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tworzenie";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::hiddenAnaconda.Properties.Resources.Programming_Edit_Property_icon;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pojazdy
            // 
            this.pojazdy.Location = new System.Drawing.Point(25, 51);
            this.pojazdy.Margin = new System.Windows.Forms.Padding(2);
            this.pojazdy.Name = "pojazdy";
            this.pojazdy.Size = new System.Drawing.Size(130, 30);
            this.pojazdy.TabIndex = 0;
            this.pojazdy.Text = "Tworzenie pojazdów";
            this.pojazdy.UseVisualStyleBackColor = true;
            this.pojazdy.Click += new System.EventHandler(this.Pojazd_Click);
            // 
            // przystanki
            // 
            this.przystanki.Location = new System.Drawing.Point(25, 85);
            this.przystanki.Margin = new System.Windows.Forms.Padding(2);
            this.przystanki.Name = "przystanki";
            this.przystanki.Size = new System.Drawing.Size(130, 30);
            this.przystanki.TabIndex = 1;
            this.przystanki.Text = "Tworzenie przystanków";
            this.przystanki.UseVisualStyleBackColor = true;
            this.przystanki.Click += new System.EventHandler(this.Przystanek_Click);
            // 
            // linie
            // 
            this.linie.Location = new System.Drawing.Point(25, 119);
            this.linie.Margin = new System.Windows.Forms.Padding(2);
            this.linie.Name = "linie";
            this.linie.Size = new System.Drawing.Size(130, 40);
            this.linie.TabIndex = 2;
            this.linie.Text = "Tworzenie linii autobusowych";
            this.linie.UseVisualStyleBackColor = true;
            this.linie.Click += new System.EventHandler(this.Linia_Click);
            // 
            // kursy
            // 
            this.kursy.Location = new System.Drawing.Point(25, 163);
            this.kursy.Margin = new System.Windows.Forms.Padding(2);
            this.kursy.Name = "kursy";
            this.kursy.Size = new System.Drawing.Size(130, 30);
            this.kursy.TabIndex = 3;
            this.kursy.Text = "Tworzenie kursów";
            this.kursy.UseVisualStyleBackColor = true;
            this.kursy.Click += new System.EventHandler(this.Kurs_Click);
            // 
            // terminyKursowania
            // 
            this.terminyKursowania.Location = new System.Drawing.Point(25, 197);
            this.terminyKursowania.Margin = new System.Windows.Forms.Padding(2);
            this.terminyKursowania.Name = "terminyKursowania";
            this.terminyKursowania.Size = new System.Drawing.Size(130, 40);
            this.terminyKursowania.TabIndex = 4;
            this.terminyKursowania.Text = "Tworzenie terminów kursowania";
            this.terminyKursowania.UseVisualStyleBackColor = true;
            this.terminyKursowania.Click += new System.EventHandler(this.Button2_Click);
            // 
            // create
            // 
            this.create.Location = new System.Drawing.Point(16, 339);
            this.create.Name = "create";
            this.create.Size = new System.Drawing.Size(80, 30);
            this.create.TabIndex = 14;
            this.create.TabStop = false;
            this.create.Text = "Zakończ";
            this.create.UseVisualStyleBackColor = true;
            this.create.Click += new System.EventHandler(this.Create_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.exit.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.exit.FlatAppearance.BorderSize = 0;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.exit.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.exit.Location = new System.Drawing.Point(566, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(44, 30);
            this.exit.TabIndex = 0;
            this.exit.TabStop = false;
            this.exit.Text = "X";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.Exit_Click);
            this.exit.MouseEnter += new System.EventHandler(this.Hover_exitbutton);
            this.exit.MouseLeave += new System.EventHandler(this.Leave_exitbutton);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(27, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(197, 21);
            this.label3.TabIndex = 7;
            this.label3.Text = "Hidden Anaconda Project";
            this.label3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Move_window);
            // 
            // help
            // 
            this.help.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.help.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.help.FlatAppearance.BorderSize = 0;
            this.help.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.help.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.help.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.help.Location = new System.Drawing.Point(522, 0);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(44, 30);
            this.help.TabIndex = 0;
            this.help.TabStop = false;
            this.help.Text = "?";
            this.help.UseVisualStyleBackColor = false;
            this.help.Click += new System.EventHandler(this.help_Click);
            this.help.MouseEnter += new System.EventHandler(this.Hover_helpbutton);
            this.help.MouseLeave += new System.EventHandler(this.Leave_helpbutton);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::hiddenAnaconda.Properties.Resources.icon;
            this.pictureBox3.Location = new System.Drawing.Point(4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(24, 24);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 48;
            this.pictureBox3.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // helpProvider1
            // 
            this.helpProvider1.HelpNamespace = "../../Resources/Help/Pomoc.chm";
            // 
            // WybórEkranu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(99)))), ((int)(((byte)(183)))));
            this.ClientSize = new System.Drawing.Size(610, 410);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.help);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.helpProvider1.SetHelpKeyword(this, "Ekran%20wyboru%20widoków.htm");
            this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "WybórEkranu";
            this.helpProvider1.SetShowHelp(this, true);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WybórEkranu";
            this.Activated += new System.EventHandler(this.TurnoffFocus);
            this.Load += new System.EventHandler(this.WybórEkranu_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Move_window);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button czasyRealizacje;
        private System.Windows.Forms.Button kursyPrzypisanie;
        private System.Windows.Forms.Button kursy;
        private System.Windows.Forms.Button kierowcy;
        private System.Windows.Forms.Button pojazdy;
        private System.Windows.Forms.Button przystanki;
        private System.Windows.Forms.Button trasyZarzadzanie;
        private System.Windows.Forms.Button linie;
        private System.Windows.Forms.Button help;
        private System.Windows.Forms.Button create;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button terminyKursowania;
        private System.Windows.Forms.Button statusZmiana;
        private System.Windows.Forms.Button Raport;
        private System.Windows.Forms.Button uzytkownicy;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button uzytkownicyEdycja;
        private System.Windows.Forms.Button Wyloguj;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label hello;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.HelpProvider helpProvider1;
    }
}